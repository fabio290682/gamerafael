import express from "express";
import { createServer as createViteServer } from "vite";
import Database from "better-sqlite3";
import path from "path";
import { fileURLToPath } from "url";
import { createServer } from "http";
import { Server } from "socket.io";

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const db = new Database("maps.db");

// Initialize database
db.exec(`
  CREATE TABLE IF NOT EXISTS maps (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    name TEXT NOT NULL,
    grid_size INTEGER NOT NULL,
    data TEXT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
  )
`);

async function startServer() {
  const app = express();
  const httpServer = createServer(app);
  const io = new Server(httpServer, {
    cors: {
      origin: "*",
      methods: ["GET", "POST"]
    }
  });

  const PORT = 3000;

  app.use(express.json({ limit: '10mb' }));

  // Socket.io Logic
  io.on("connection", (socket) => {
    console.log("User connected:", socket.id);

    socket.on("join_room", (roomId) => {
      socket.join(roomId);
      console.log(`User ${socket.id} joined room ${roomId}`);
    });

    socket.on("sync_grid", ({ roomId, grid }) => {
      socket.to(roomId).emit("grid_updated", grid);
    });

    socket.on("start_battle", ({ roomId, f1, f2 }) => {
      socket.to(roomId).emit("battle_started", { f1, f2 });
    });

    socket.on("reset_battle", (roomId) => {
      socket.to(roomId).emit("battle_reset");
    });

    socket.on("disconnect", () => {
      console.log("User disconnected:", socket.id);
    });
  });

  // API Routes
  app.get("/api/maps", (req, res) => {
    try {
      const maps = db.prepare("SELECT id, name, grid_size, created_at FROM maps ORDER BY created_at DESC").all();
      res.json(maps);
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch maps" });
    }
  });

  app.get("/api/maps/:id", (req, res) => {
    try {
      const map = db.prepare("SELECT * FROM maps WHERE id = ?").get(req.params.id) as any;
      if (map) {
        res.json({
          ...map,
          data: JSON.parse(map.data as string)
        });
      } else {
        res.status(404).json({ error: "Map not found" });
      }
    } catch (error) {
      res.status(500).json({ error: "Failed to fetch map" });
    }
  });

  app.post("/api/maps", (req, res) => {
    const { name, gridSize, data } = req.body;
    if (!name || !gridSize || !data) {
      return res.status(400).json({ error: "Missing required fields" });
    }

    try {
      const info = db.prepare("INSERT INTO maps (name, grid_size, data) VALUES (?, ?, ?)").run(
        name,
        gridSize,
        JSON.stringify(data)
      );
      res.json({ id: info.lastInsertRowid, name, gridSize });
    } catch (error) {
      res.status(500).json({ error: "Failed to save map" });
    }
  });

  app.delete("/api/maps/:id", (req, res) => {
    try {
      db.prepare("DELETE FROM maps WHERE id = ?").run(req.params.id);
      res.json({ success: true });
    } catch (error) {
      res.status(500).json({ error: "Failed to delete map" });
    }
  });

  // Vite middleware for development
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    app.use(express.static(path.join(__dirname, "dist")));
    app.get("*", (req, res) => {
      res.sendFile(path.join(__dirname, "dist", "index.html"));
    });
  }

  httpServer.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on http://localhost:${PORT}`);
  });
}

startServer();
