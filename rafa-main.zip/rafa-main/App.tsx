
import React, { useState, useEffect, useRef } from 'react';
import { AVAILABLE_GRID_SIZES, DEFAULT_GRID_SIZE, ASSETS, CATEGORIES } from './constants';
import { MapCell, TileData } from './types';
import { generateMapStory } from './services/geminiService';
import { io, Socket } from 'socket.io-client';
import { musicGenerator } from './services/musicService';

// --- Sub-components ---

const renderEmoji = (emoji: string, assetId: string) => {
  if (assetId === 'f_user_custom') {
    const parts = Array.from(emoji);
    return (
      <span className="flex items-center justify-center">
        {parts.map((char, i) => {
          if (char === '⭐') {
            return (
              <span 
                key={i} 
                className="inline-block"
                style={{ 
                  background: 'linear-gradient(to bottom, #ffff00, #ffffff)',
                  WebkitBackgroundClip: 'text',
                  WebkitTextFillColor: 'transparent',
                }}
              >
                {char}
              </span>
            );
          }
          return <span key={i}>{char}</span>;
        })}
      </span>
    );
  }
  return emoji;
};

interface SidebarProps {
  selectedTile: string | null;
  onSelectTile: (id: string) => void;
  gridSize: number;
  onGridSizeChange: (size: number) => void;
}

const Sidebar: React.FC<SidebarProps> = ({ selectedTile, onSelectTile, gridSize, onGridSizeChange }) => {
  const [activeTab, setActiveTab] = useState('ground');

  return (
    <div className="w-80 h-full bg-[#fdf5e6] border-r-4 border-[#8b4513] flex flex-col overflow-hidden shadow-2xl z-10">
      <div className="p-6 bg-[#8b4513] text-white">
        <h1 className="text-2xl font-bold flex items-center gap-2">
          <span>🗺️</span> Explorador
        </h1>
        <p className="text-xs opacity-80 uppercase tracking-widest font-bold">Crie seu Próprio Mapa</p>
      </div>

      <div className="p-4 bg-[#f8ecd4] border-b border-[#d2b48c]">
        <label className="text-[10px] font-bold text-[#5d4037] uppercase mb-2 block tracking-tighter">Escala do Mapa (Tamanho)</label>
        <div className="flex gap-1 overflow-x-auto pb-1 custom-scrollbar">
          {AVAILABLE_GRID_SIZES.map(size => (
            <button
              key={size}
              onClick={() => onGridSizeChange(size)}
              className={`px-3 py-1 rounded-md text-xs font-bold transition-all flex-shrink-0 ${
                gridSize === size 
                  ? 'bg-[#8b4513] text-white shadow-md' 
                  : 'bg-white/50 text-[#8b4513] border border-[#d2b48c] hover:bg-white'
              }`}
            >
              {size}x{size}
            </button>
          ))}
        </div>
      </div>
      
      <div className="flex bg-[#d2b48c] p-1 gap-1 overflow-x-auto custom-scrollbar scrollbar-hide">
        {CATEGORIES.map((cat) => (
          <button
            key={cat.id}
            onClick={() => setActiveTab(cat.id)}
            className={`flex-shrink-0 py-2 px-3 rounded-lg text-[9px] font-black transition-all uppercase tracking-tighter ${
              activeTab === cat.id ? 'bg-[#fdf5e6] text-[#8b4513] shadow-sm' : 'text-[#5d4037] hover:bg-white/30'
            }`}
          >
            <div className="text-sm">{cat.icon}</div>
            {cat.label}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-4 custom-scrollbar bg-[url('https://www.transparenttextures.com/patterns/p6.png')]">
        <div className="grid grid-cols-2 gap-3">
            {ASSETS.filter(a => a.category === activeTab).map((asset) => {
              const isColor = asset.category.startsWith('colors_');
              return (
                <button
                  key={asset.id}
                  onClick={() => onSelectTile(asset.id)}
                  className={`p-3 rounded-xl border-2 transition-all flex flex-col items-center gap-1 tile-hover ${
                    selectedTile === asset.id 
                      ? 'border-[#8b4513] bg-white ring-2 ring-[#d2b48c]' 
                      : 'border-transparent bg-white/40 hover:bg-white hover:border-[#d2b48c]'
                  }`}
                >
                  {asset.colorCode ? (
                    <div 
                      className="w-10 h-10 rounded-lg shadow-inner border border-black/10 flex items-center justify-center overflow-hidden" 
                      style={{ background: asset.colorCode }}
                    >
                      {!isColor && <span className="text-xl">{renderEmoji(asset.emoji, asset.id)}</span>}
                    </div>
                  ) : (
                    <span className="text-4xl">{renderEmoji(asset.emoji, asset.id)}</span>
                  )}
                  <span className="text-[10px] font-bold text-[#5d4037] uppercase tracking-wider text-center">{asset.label}</span>
                </button>
              );
            })}
        </div>
      </div>
      
      <div className="p-4 bg-[#fdf5e6] border-t border-[#d2b48c] text-center">
        <p className="text-[9px] text-[#8b4513] font-bold uppercase tracking-[0.2em]">
          Desenvolvido por <span className="underline decoration-2">Rafael Araujo</span>
        </p>
      </div>
    </div>
  );
};

const App: React.FC = () => {
  const [gridSize, setGridSize] = useState<number>(DEFAULT_GRID_SIZE);
  const [grid, setGrid] = useState<MapCell[][]>([]);
  const [selectedTileId, setSelectedTileId] = useState<string | null>('grass');
  const [isStoryLoading, setIsStoryLoading] = useState(false);
  const [story, setStory] = useState<{title: string, story: string} | null>(null);
  const [showStory, setShowStory] = useState(false);
  const [savedMaps, setSavedMaps] = useState<any[]>([]);
  const [showSavedMaps, setShowSavedMaps] = useState(false);
  const [mapName, setMapName] = useState('');
  const [isFightMode, setIsFightMode] = useState(false);
  const [fighter1, setFighter1] = useState<{x: number, y: number} | null>(null);
  const [fighter2, setFighter2] = useState<{x: number, y: number} | null>(null);
  const [battleLog, setBattleLog] = useState<string[]>([]);
  const [isFighting, setIsFighting] = useState(false);
  const [battleWinner, setBattleWinner] = useState<string | null>(null);
  const [roomId, setRoomId] = useState('global');
  const [isMusicPlaying, setIsMusicPlaying] = useState(false);
  const socketRef = useRef<Socket | null>(null);

  useEffect(() => {
    return () => {
      musicGenerator.stop();
    };
  }, []);

  const toggleMusic = () => {
    if (isMusicPlaying) {
      musicGenerator.stop();
    } else {
      musicGenerator.start();
    }
    setIsMusicPlaying(!isMusicPlaying);
  };

  useEffect(() => {
    socketRef.current = io();
    
    socketRef.current.on('connect', () => {
      socketRef.current?.emit('join_room', roomId);
    });

    socketRef.current.on('grid_updated', (newGrid: MapCell[][]) => {
      setGrid(newGrid);
    });

    socketRef.current.on('battle_started', ({ f1, f2 }: { f1: {x: number, y: number}, f2: {x: number, y: number} }) => {
      setFighter1(f1);
      setFighter2(f2);
      // We don't call startBattle directly to avoid double simulation if possible, 
      // but for simplicity we'll let each client simulate the same battle.
      // In a real app, the server would authoritative the battle.
      triggerLocalBattle(f1, f2);
    });

    socketRef.current.on('battle_reset', () => {
      localResetFight();
    });

    return () => {
      socketRef.current?.disconnect();
    };
  }, [roomId]);

  useEffect(() => {
    initGrid();
    fetchSavedMaps();
  }, [gridSize]);

  const fetchSavedMaps = async () => {
    try {
      const response = await fetch('/api/maps');
      const data = await response.json();
      setSavedMaps(data);
    } catch (error) {
      console.error('Failed to fetch maps:', error);
    }
  };

  const saveMap = async () => {
    const name = prompt('Dê um nome para o seu mapa:', mapName || 'Meu Mapa');
    if (!name) return;

    try {
      const response = await fetch('/api/maps', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          name,
          gridSize,
          data: grid
        })
      });
      if (response.ok) {
        alert('Mapa salvo com sucesso!');
        fetchSavedMaps();
      }
    } catch (error) {
      alert('Erro ao salvar o mapa.');
    }
  };

  const loadMap = async (id: number) => {
    try {
      const response = await fetch(`/api/maps/${id}`);
      const data = await response.json();
      setGridSize(data.grid_size);
      setGrid(data.data);
      socketRef.current?.emit('sync_grid', { roomId, grid: data.data });
      setMapName(data.name);
      setShowSavedMaps(false);
    } catch (error) {
      alert('Erro ao carregar o mapa.');
    }
  };

  const deleteMap = async (id: number) => {
    if (!confirm('Tem certeza que deseja excluir este mapa?')) return;
    try {
      await fetch(`/api/maps/${id}`, { method: 'DELETE' });
      fetchSavedMaps();
    } catch (error) {
      alert('Erro ao excluir o mapa.');
    }
  };

  const initGrid = () => {
    const newGrid: MapCell[][] = [];
    for (let y = 0; y < gridSize; y++) {
      const row: MapCell[] = [];
      for (let x = 0; x < gridSize; x++) {
        row.push({ x, y, tileId: null });
      }
      newGrid.push(row);
    }
    setGrid(newGrid);
    setStory(null);
  };

  const handleCellClick = (x: number, y: number) => {
    if (isFightMode) {
      const cell = grid[y][x];
      if (!cell.tileId) return;
      
      const asset = ASSETS.find(a => a.id === cell.tileId);
      const isCombatant = ['character', 'anime', 'heroes', 'villains', 'monsters'].includes(asset?.category || '');
      
      if (!isCombatant) {
        alert('Este item não pode lutar! Selecione um personagem ou monstro.');
        return;
      }

      if (!fighter1) {
        setFighter1({ x, y });
      } else if (!fighter2) {
        if (fighter1.x === x && fighter1.y === y) return;
        setFighter2({ x, y });
        startBattle({ x, y }, fighter1);
      }
      return;
    }

    const newGrid = [...grid];
    if (selectedTileId === 'eraser') {
      newGrid[y][x].tileId = null;
    } else {
      // Toggle logic: if clicking same tile, remove it. Otherwise place it.
      newGrid[y][x].tileId = newGrid[y][x].tileId === selectedTileId ? null : selectedTileId;
    }
    setGrid(newGrid);
    socketRef.current?.emit('sync_grid', { roomId, grid: newGrid });
  };

  const startBattle = async (f1: {x: number, y: number}, f2: {x: number, y: number}) => {
    socketRef.current?.emit('start_battle', { roomId, f1, f2 });
    triggerLocalBattle(f1, f2);
  };

  const triggerLocalBattle = async (f1: {x: number, y: number}, f2: {x: number, y: number}) => {
    setIsFighting(true);
    setBattleLog(['⚔️ O combate começou!']);
    
    const asset1 = ASSETS.find(a => a.id === grid[f1.y][f1.x].tileId);
    const asset2 = ASSETS.find(a => a.id === grid[f2.y][f2.x].tileId);
    
    if (!asset1 || !asset2) {
      setIsFighting(false);
      return;
    }

    const getSpecialMove = (id: string) => {
      const moves: Record<string, string> = {
        'a_goku': 'KAMEHAMEHA! 💥',
        'a_vegeta': 'GALICK GUN! ⚡',
        'a_broly': 'OMEGA BLASTER! 🟢',
        'a_luffy': 'GOMU GOMU NO PISTOL! 🥊',
        'a_zoro': 'SANTORYU: ONIGIRI! ⚔️',
        'dragon': 'SOPRO DE FOGO! 🔥',
        'a_naruto': 'RASENGAN! 🌀',
        'a_sasuke': 'CHIDORI! ⚡'
      };
      return moves[id] || 'um ataque especial! 🔥';
    };

    const log = [
      `⚔️ ${asset1.label} desafiou ${asset2.label}!`,
      `📍 O combate ocorre em (${f1.x}, ${f1.y}) contra (${f2.x}, ${f2.y}).`
    ];
    setBattleLog([...log]);

    // Simulate turns
    setTimeout(() => {
      setBattleLog(prev => [...prev, `💥 ${asset1.label} usa ${getSpecialMove(asset1.id)}`]);
    }, 1000);

    setTimeout(() => {
      setBattleLog(prev => [...prev, `🛡️ ${asset2.label} tenta se defender com tudo!`]);
    }, 2000);

    setTimeout(() => {
      const winner = Math.random() > 0.5 ? asset1 : asset2;
      setBattleWinner(winner.label);
      setBattleLog(prev => [...prev, `🏆 O vencedor é ${winner.label}!`]);
      setIsFighting(false);
    }, 3500);
  };

  const resetFight = () => {
    socketRef.current?.emit('reset_battle', roomId);
    localResetFight();
  };

  const localResetFight = () => {
    setFighter1(null);
    setFighter2(null);
    setBattleLog([]);
    setBattleWinner(null);
    setIsFighting(false);
  };

  const clearAll = () => {
    if (confirm(`Limpar todos os ${gridSize * gridSize} quadrados do mapa?`)) {
      const newGrid: MapCell[][] = [];
      for (let y = 0; y < gridSize; y++) {
        const row: MapCell[] = [];
        for (let x = 0; x < gridSize; x++) {
          row.push({ x, y, tileId: null });
        }
        newGrid.push(row);
      }
      setGrid(newGrid);
      socketRef.current?.emit('sync_grid', { roomId, grid: newGrid });
    }
  };

  const fillAll = () => {
    if (!selectedTileId || selectedTileId === 'eraser') {
      alert('Selecione um item ou cor (como grama ou azul) para pintar o mapa todo!');
      return;
    }
    const asset = ASSETS.find(a => a.id === selectedTileId);
    if (confirm(`Pintar o mapa inteiro de ${asset?.label}?`)) {
      const newGrid = grid.map(row => row.map(cell => ({ ...cell, tileId: selectedTileId })));
      setGrid(newGrid);
    }
  };

  const generateContinents = () => {
    const newGrid: MapCell[][] = [];
    for (let y = 0; y < gridSize; y++) {
      const row: MapCell[] = [];
      for (let x = 0; x < gridSize; x++) {
        row.push({ x, y, tileId: 'water' });
      }
      newGrid.push(row);
    }

    const seedCount = Math.max(3, Math.floor(gridSize / 3));
    const iterations = Math.max(4, Math.floor(gridSize / 2));

    for (let i = 0; i < seedCount; i++) {
      const sx = Math.floor(Math.random() * gridSize);
      const sy = Math.floor(Math.random() * gridSize);
      newGrid[sy][sx].tileId = 'grass';
    }

    for (let iter = 0; iter < iterations; iter++) {
      const tempGrid = JSON.parse(JSON.stringify(newGrid));
      for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
          if (newGrid[y][x].tileId === 'water') {
            let grassNeighbors = 0;
            for (let dy = -1; dy <= 1; dy++) {
              for (let dx = -1; dx <= 1; dx++) {
                const nx = x + dx;
                const ny = y + dy;
                if (nx >= 0 && nx < gridSize && ny >= 0 && ny < gridSize) {
                  if (newGrid[ny][nx].tileId === 'grass') grassNeighbors++;
                }
              }
            }
            if (grassNeighbors > 0 && Math.random() < (grassNeighbors * 0.22)) {
              tempGrid[y][x].tileId = 'grass';
            }
          }
        }
      }
      for (let y = 0; y < gridSize; y++) {
        for (let x = 0; x < gridSize; x++) {
          newGrid[y][x].tileId = tempGrid[y][x].tileId;
        }
      }
    }
    setGrid([...newGrid]);
  };

  const handleGenerateStory = async () => {
    setIsStoryLoading(true);
    const result = await generateMapStory(grid, ASSETS);
    setStory(result);
    setIsStoryLoading(false);
    setShowStory(true);
  };

  const getCoordinateLabel = (i: number) => {
    const letters = 'ABCDEFGHIJKLMNOPQRSTUVWXYZ'.split('');
    const first = Math.floor(i / 26);
    const second = i % 26;
    return first === 0 ? letters[second] : letters[first - 1] + letters[second];
  };

  const getFontSize = () => {
    if (gridSize > 40) return 'text-[6px]';
    if (gridSize > 20) return 'text-xs';
    return 'text-2xl md:text-4xl';
  };

  return (
    <div className="flex h-screen bg-[#1a252f] overflow-hidden">
      <Sidebar 
        selectedTile={selectedTileId} 
        onSelectTile={setSelectedTileId} 
        gridSize={gridSize}
        onGridSizeChange={setGridSize}
      />

      <div className="flex-1 flex flex-col items-center justify-center p-4 relative overflow-auto">
        <div className="mb-4 text-center flex flex-col items-center gap-2">
          <h2 className="text-white text-2xl font-black uppercase tracking-widest drop-shadow-lg">
            🗺️ Meu Mundo Mágico
          </h2>
          <div className="flex items-center gap-2 bg-black/30 px-3 py-1 rounded-full border border-white/10">
            <span className="text-[10px] font-black text-white/50 uppercase">Sala:</span>
            <input 
              type="text" 
              value={roomId} 
              onChange={(e) => setRoomId(e.target.value)}
              className="bg-transparent text-white text-xs font-black focus:outline-none w-24 text-center"
              placeholder="Nome da Sala"
            />
            <div className="w-2 h-2 rounded-full bg-green-500 animate-pulse"></div>
          </div>
        </div>

        <div className="relative parchment p-6 md:p-8 rounded-lg">
          {/* Coordinates */}
          <div className="absolute top-0 left-0 right-0 h-6 flex justify-center px-6 md:px-8 -mt-1 overflow-hidden pointer-events-none">
            {Array.from({length: gridSize}).map((_, i) => (
              <div key={i} className={`flex-1 text-center font-black text-[#8b4513]/40 ${gridSize > 30 ? 'text-[5px]' : 'text-[10px]'}`}>
                {getCoordinateLabel(i)}
              </div>
            ))}
          </div>
          
          <div className="absolute top-0 left-0 bottom-0 w-6 flex flex-col justify-center py-6 md:py-8 -ml-1 overflow-hidden pointer-events-none">
            {Array.from({length: gridSize}).map((_, i) => (
              <div key={i} className={`flex-1 flex items-center justify-center font-black text-[#8b4513]/40 ${gridSize > 30 ? 'text-[5px]' : 'text-[10px]'}`}>
                {i + 1}
              </div>
            ))}
          </div>

          <div 
            className="grid bg-[#8b4513]/5 border-2 border-[#8b4513]/20"
            style={{ 
              gridTemplateColumns: `repeat(${gridSize}, minmax(0, 1fr))`,
              width: 'min(80vw, 75vh)',
              height: 'min(80vw, 75vh)'
            }}
          >
            {grid.map((row, y) => 
              row.map((cell, x) => {
                const asset = ASSETS.find(a => a.id === cell.tileId);
                const isColor = asset?.category === 'colors_light' || asset?.category === 'colors_dark' || asset?.category === 'colors_vibrant' || asset?.category === 'colors_gradient' || asset?.category === 'colors_standard' || asset?.category === 'colors_opaque';
                const isFighter1 = fighter1?.x === x && fighter1?.y === y;
                const isFighter2 = fighter2?.x === x && fighter2?.y === y;

                return (
                  <div
                    key={`${x}-${y}`}
                    onClick={() => handleCellClick(x, y)}
                    className={`aspect-square flex items-center justify-center cursor-pointer transition-all select-none active:scale-95 overflow-hidden ${
                      gridSize > 40 ? 'border-0' : 'border border-[#8b4513]/5'
                    } ${cell.tileId && !isColor ? 'bg-white/20' : 'hover:bg-black/5'} ${getFontSize()} ${
                      isFighter1 ? 'ring-4 ring-red-500 z-10 animate-pulse' : ''
                    } ${
                      isFighter2 ? 'ring-4 ring-blue-500 z-10 animate-pulse' : ''
                    }`}
                    style={{ background: asset?.colorCode || 'transparent' }}
                  >
                    {!isColor && asset ? renderEmoji(asset.emoji, asset.id) : ''}
                  </div>
                );
              })
            )}
          </div>
        </div>

        {/* TOOLBAR */}
        <div className="mt-6 flex flex-wrap justify-center gap-2 z-10 max-w-4xl px-4">
          <button 
            onClick={() => {
              setIsFightMode(!isFightMode);
              resetFight();
            }}
            className={`px-5 py-3 rounded-xl font-black text-sm shadow-lg border-b-4 transition-all ${
              isFightMode 
                ? 'bg-red-600 border-red-800 text-white ring-4 ring-red-300' 
                : 'bg-zinc-700 border-zinc-900 text-white hover:bg-zinc-600'
            }`}
          >
            <span>⚔️</span> {isFightMode ? 'Sair do Modo Luta' : 'Modo de Luta'}
          </button>

          <button 
            onClick={generateContinents}
            className="px-5 py-3 rounded-xl bg-blue-500 text-white font-black text-sm shadow-lg border-b-4 border-blue-700 hover:bg-blue-400 active:translate-y-1"
          >
            <span>🌏</span> Gerar Continentes
          </button>

          <button 
            onClick={fillAll}
            className="px-5 py-3 rounded-xl bg-orange-500 text-white font-black text-sm shadow-lg border-b-4 border-orange-700 hover:bg-orange-400 active:translate-y-1"
          >
            <span>🎨</span> Pintar Tudo
          </button>

          <button 
            onClick={handleGenerateStory}
            disabled={isStoryLoading}
            className={`px-6 py-3 rounded-xl text-white font-black text-sm shadow-lg border-b-4 ${
              isStoryLoading ? 'bg-gray-500 border-gray-700' : 'bg-purple-600 border-purple-800 hover:bg-purple-500 active:translate-y-1'
            }`}
          >
            {isStoryLoading ? 'Lendo o mapa...' : '📜 Criar História'}
          </button>

          <button 
            onClick={saveMap}
            className="px-5 py-3 rounded-xl bg-green-600 text-white font-black text-sm shadow-lg border-b-4 border-green-800 hover:bg-green-500 active:translate-y-1"
          >
            <span>💾</span> Salvar Mapa
          </button>

          <button 
            onClick={() => setShowSavedMaps(true)}
            className="px-5 py-3 rounded-xl bg-amber-600 text-white font-black text-sm shadow-lg border-b-4 border-amber-800 hover:bg-amber-500 active:translate-y-1"
          >
            <span>📁</span> Meus Mapas
          </button>

          <button 
            onClick={clearAll}
            className="px-5 py-3 rounded-xl bg-red-500 text-white font-black text-sm shadow-lg border-b-4 border-red-800 hover:bg-red-400 active:translate-y-1"
          >
            <span>🧹</span> Limpar Tudo
          </button>
        </div>
      </div>

      {/* SAVED MAPS MODAL */}
      {showSavedMaps && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#fdf5e6] parchment p-8 max-w-2xl w-full shadow-2xl relative">
            <button 
              onClick={() => setShowSavedMaps(false)}
              className="absolute top-4 right-4 text-[#8b4513] text-2xl font-black"
            >
              ✕
            </button>
            <h2 className="text-2xl font-black text-[#5d4037] mb-6 uppercase text-center">📁 Meus Mapas Salvos</h2>
            
            <div className="max-h-[60vh] overflow-y-auto custom-scrollbar pr-2">
              {savedMaps.length === 0 ? (
                <p className="text-center text-[#8b4513] italic">Nenhum mapa salvo ainda...</p>
              ) : (
                <div className="grid gap-3">
                  {savedMaps.map(m => (
                    <div key={m.id} className="bg-white/50 p-4 rounded-xl border border-[#d2b48c] flex items-center justify-between hover:bg-white transition-all">
                      <div>
                        <h3 className="font-black text-[#5d4037]">{m.name}</h3>
                        <p className="text-[10px] text-[#8b4513] uppercase font-bold">Tamanho: {m.grid_size}x{m.grid_size} • {new Date(m.created_at).toLocaleDateString()}</p>
                      </div>
                      <div className="flex gap-2">
                        <button 
                          onClick={() => loadMap(m.id)}
                          className="p-2 bg-blue-500 text-white rounded-lg hover:bg-blue-600 transition-all"
                          title="Carregar"
                        >
                          📂
                        </button>
                        <button 
                          onClick={() => deleteMap(m.id)}
                          className="p-2 bg-red-500 text-white rounded-lg hover:bg-red-600 transition-all"
                          title="Excluir"
                        >
                          🗑️
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
            
            <div className="mt-8 text-center">
              <button 
                onClick={() => setShowSavedMaps(false)}
                className="px-8 py-2 bg-[#8b4513] text-white rounded-xl font-black"
              >
                Fechar
              </button>
            </div>
          </div>
        </div>
      )}

      {/* BATTLE OVERLAY */}
      {(isFighting || battleLog.length > 0) && isFightMode && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60]">
          <div className="bg-zinc-900 border-4 border-red-600 rounded-2xl w-full max-w-md p-6 shadow-2xl animate-in fade-in zoom-in duration-300">
            <div className="flex justify-between items-center mb-6">
              <h2 className="text-red-500 text-2xl font-black uppercase italic tracking-tighter">Arena de Combate</h2>
              {!isFighting && (
                <button onClick={resetFight} className="text-white/50 hover:text-white">✕</button>
              )}
            </div>

            {/* VS DISPLAY */}
            {(() => {
              const f1 = fighter1 ? grid[fighter1.y][fighter1.x] : null;
              const f2 = fighter2 ? grid[fighter2.y][fighter2.x] : null;
              const asset1 = f1 ? ASSETS.find(a => a.id === f1.tileId) : null;
              const asset2 = f2 ? ASSETS.find(a => a.id === f2.tileId) : null;
              
              if (!asset1 || !asset2) return null;

              return (
                <div className="flex items-center justify-between mb-8 gap-4 bg-black/40 p-4 rounded-xl border border-white/10">
                  <div className="flex flex-col items-center flex-1">
                    <div className="text-4xl mb-2 bg-white/5 w-16 h-16 flex items-center justify-center rounded-full border-2 border-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]">
                      {renderEmoji(asset1.emoji, asset1.id)}
                    </div>
                    <div className="text-[10px] font-black text-white uppercase text-center truncate w-full">{asset1.label}</div>
                  </div>
                  
                  <div className="text-2xl font-black text-red-600 italic animate-pulse">VS</div>
                  
                  <div className="flex flex-col items-center flex-1">
                    <div className="text-4xl mb-2 bg-white/5 w-16 h-16 flex items-center justify-center rounded-full border-2 border-blue-500 shadow-[0_0_15px_rgba(59,130,246,0.3)]">
                      {renderEmoji(asset2.emoji, asset2.id)}
                    </div>
                    <div className="text-[10px] font-black text-white uppercase text-center truncate w-full">{asset2.label}</div>
                  </div>
                </div>
              );
            })()}

            <div className="space-y-3 mb-8 max-h-40 overflow-y-auto custom-scrollbar pr-2">
              {battleLog.map((line, i) => (
                <div key={i} className={`text-sm font-bold ${i === battleLog.length - 1 ? 'text-white animate-pulse' : 'text-white/60'}`}>
                  {line}
                </div>
              ))}
            </div>

            {battleWinner && (
              <div className="text-center p-6 bg-red-600/20 border-2 border-red-600 rounded-xl mb-6 animate-bounce">
                <div className="text-xs text-red-400 font-black uppercase mb-1">Vencedor</div>
                <div className="text-3xl text-white font-black uppercase tracking-widest drop-shadow-[0_2px_2px_rgba(0,0,0,0.8)]">
                  {battleWinner}
                </div>
              </div>
            )}

            {!isFighting && (
              <button 
                onClick={resetFight}
                className="w-full py-4 bg-red-600 text-white font-black uppercase tracking-widest rounded-xl shadow-lg border-b-4 border-red-800 hover:bg-red-500 active:translate-y-1"
              >
                Próximo Combate
              </button>
            )}
          </div>
        </div>
      )}

      {/* MUSIC TOGGLE */}
      <button
        onClick={toggleMusic}
        className={`fixed bottom-6 right-6 w-14 h-14 rounded-full flex items-center justify-center text-2xl shadow-2xl z-50 transition-all hover:scale-110 active:scale-95 border-4 ${
          isMusicPlaying 
            ? 'bg-emerald-500 border-white text-white animate-pulse' 
            : 'bg-zinc-800 border-zinc-600 text-zinc-400'
        }`}
        title={isMusicPlaying ? 'Pausar Música' : 'Tocar Música'}
      >
        {isMusicPlaying ? '🎵' : '🔇'}
      </button>

      {/* FIGHT MODE HINT */}
      {isFightMode && !isFighting && !battleWinner && (
        <div className="fixed bottom-10 left-1/2 -translate-x-1/2 flex flex-col items-center gap-4 z-50">
          <div className="flex gap-2 bg-black/80 p-2 rounded-2xl border-2 border-red-600 backdrop-blur-md shadow-2xl">
            {['a_goku', 'a_vegeta', 'a_broly', 'a_luffy', 'a_zoro', 'a_naruto', 'a_sasuke'].map(id => {
              const asset = ASSETS.find(a => a.id === id);
              return (
                <button
                  key={id}
                  onClick={() => setSelectedTileId(id)}
                  className={`w-12 h-12 rounded-xl flex items-center justify-center text-2xl transition-all hover:scale-110 ${
                    selectedTileId === id ? 'bg-red-600 ring-2 ring-white' : 'bg-white/10 hover:bg-white/20'
                  }`}
                  title={asset?.label}
                >
                  {asset?.emoji}
                </button>
              );
            })}
          </div>
          <div className="bg-red-600 text-white px-8 py-4 rounded-full font-black uppercase tracking-widest shadow-2xl animate-bounce border-4 border-white">
            {fighter1 ? 'Selecione o Oponente' : 'Selecione o Primeiro Lutador'}
          </div>
        </div>
      )}

      {/* STORY MODAL */}
      {showStory && story && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-sm flex items-center justify-center p-4 z-50">
          <div className="bg-[#fdf5e6] parchment p-8 md:p-12 max-w-2xl w-full shadow-2xl relative text-center">
            <button 
              onClick={() => setShowStory(false)}
              className="absolute top-4 right-4 text-[#8b4513] text-2xl font-black"
            >
              ✕
            </button>
            <div className="text-5xl mb-4">📜</div>
            <h2 className="text-3xl font-black text-[#5d4037] mb-6 uppercase tracking-tight">
                {story.title}
            </h2>
            <p className="text-xl text-[#5d4037] leading-relaxed italic font-serif">
                "{story.story}"
            </p>
            <button 
                onClick={() => setShowStory(false)}
                className="mt-8 px-10 py-3 bg-[#8b4513] text-white rounded-xl font-black hover:bg-black transition-all"
            >
                Uau, que legal!
            </button>
          </div>
        </div>
      )}
    </div>
  );
};

export default App;
