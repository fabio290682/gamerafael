
import { GoogleGenAI, Type } from "@google/genai";
import { MapCell, TileData, StoryResponse } from "../types";

// Generates a short story based on the current map layout using Gemini 3 Flash.
export const generateMapStory = async (grid: MapCell[][], assets: TileData[]): Promise<StoryResponse> => {
  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });
  
  // Summarize what's on the map for the prompt
  const placedItems = grid.flat()
    .filter(cell => cell.tileId !== null)
    .map(cell => assets.find(a => a.id === cell.tileId)?.label);
  
  const itemsCount = placedItems.reduce((acc: Record<string, number>, curr) => {
    if (!curr) return acc;
    acc[curr] = (acc[curr] || 0) + 1;
    return acc;
  }, {});

  const prompt = `Estou criando um mapa de brinquedo. No meu mapa eu coloquei: ${JSON.stringify(itemsCount)}. 
  Crie uma historinha de aventura muito curta (3 frases) e um título divertido para uma criança de 5 anos sobre esse mundo. 
  Responda em Português do Brasil no formato JSON.`;

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: prompt,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.OBJECT,
          properties: {
            title: { type: Type.STRING },
            story: { type: Type.STRING }
          },
          required: ["title", "story"]
        }
      }
    });

    // Access the .text property directly as per latest SDK guidelines.
    const text = response.text;
    if (!text) {
      throw new Error("Received empty response from Gemini API");
    }
    
    return JSON.parse(text) as StoryResponse;
  } catch (error) {
    console.error("Gemini Error:", error);
    return { 
      title: "Uma Aventura Surpresa!", 
      story: "Seu mapa parece um lugar mágico onde tudo pode acontecer. O que você vai criar agora?" 
    };
  }
};
