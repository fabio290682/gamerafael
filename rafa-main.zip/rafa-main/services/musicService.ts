
export class ProceduralMusic {
  private audioCtx: AudioContext | null = null;
  private isPlaying: boolean = false;
  private nextNoteTime: number = 0;
  private notes: number[] = [261.63, 293.66, 329.63, 349.23, 392.00, 440.00, 493.88, 523.25, 587.33, 659.25]; // C4 to E5
  private melody: number[] = [
    0, 4, 7, 4, 
    2, 5, 9, 5, 
    0, 4, 7, 4, 
    7, 6, 5, 4,
    0, 4, 7, 4,
    2, 5, 9, 5,
    7, 8, 9, 7,
    4, 2, 0, 0
  ]; 
  private currentNoteIndex: number = 0;
  private timerId: number | null = null;

  constructor() {
  }

  private initAudio() {
    if (!this.audioCtx) {
      this.audioCtx = new (window.AudioContext || (window as any).webkitAudioContext)();
    }
  }

  start() {
    this.initAudio();
    if (this.isPlaying) return;
    this.isPlaying = true;
    this.nextNoteTime = this.audioCtx!.currentTime;
    this.scheduler();
  }

  stop() {
    this.isPlaying = false;
    if (this.timerId) {
      clearTimeout(this.timerId);
      this.timerId = null;
    }
  }

  private scheduler() {
    while (this.isPlaying && this.nextNoteTime < this.audioCtx!.currentTime + 0.1) {
      const isAccent = this.currentNoteIndex % 4 === 0;
      this.playNote(this.notes[this.melody[this.currentNoteIndex]], this.nextNoteTime, isAccent);
      this.nextNoteTime += 0.2; // Faster tempo
      this.currentNoteIndex = (this.currentNoteIndex + 1) % this.melody.length;
    }
    if (this.isPlaying) {
      this.timerId = window.setTimeout(() => this.scheduler(), 25);
    }
  }

  private playNote(freq: number, time: number, isAccent: boolean) {
    if (!this.audioCtx) return;
    
    const osc = this.audioCtx.createOscillator();
    const gain = this.audioCtx.createGain();

    osc.type = isAccent ? 'square' : 'triangle'; 
    osc.frequency.setValueAtTime(freq, time);
    
    const volume = isAccent ? 0.08 : 0.05;
    gain.gain.setValueAtTime(volume, time);
    gain.gain.exponentialRampToValueAtTime(0.0001, time + 0.15);

    osc.connect(gain);
    gain.connect(this.audioCtx.destination);

    osc.start(time);
    osc.stop(time + 0.15);
  }
}

export const musicGenerator = new ProceduralMusic();
