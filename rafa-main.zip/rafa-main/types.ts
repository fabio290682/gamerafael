
// Define the possible types of tiles available in the map editor.
export type TileType = 'grass' | 'water' | 'road' | 'tree' | 'house' | 'castle' | 'cat' | 'dog' | 'flower' | 'treasure' | 'mountain' | 'bridge' | 'color_block' | 'character';

export interface TileData {
  id: string;
  type: TileType;
  emoji: string;
  label: string;
  // Added 'anime' to the category union.
  category: 'ground' | 'structure' | 'nature' | 'character' | 'colors' | 'tools' | 'colors_light' | 'colors_dark' | 'colors_vibrant' | 'colors_gradient' | 'colors_standard' | 'colors_opaque' | 'powers' | 'flags' | 'anime';
  colorCode?: string;
}

export interface MapCell {
  x: number;
  y: number;
  tileId: string | null;
}

export interface StoryResponse {
  title: string;
  story: string;
}
